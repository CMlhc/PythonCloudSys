from django.contrib import admin
from firstapp.models import People

# Register your models here.
admin.site.register(People)
